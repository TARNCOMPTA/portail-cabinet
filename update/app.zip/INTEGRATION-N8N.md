# Intégration n8n (et autres outils d'automatisation)

Le portail s'intègre à n8n dans les deux sens :

1. **Webhook sortant** — le portail notifie n8n à la fin de chaque récupération (bilan JSON) ;
2. **API entrante** — n8n appelle l'API REST du portail (clients, documents, récupérations…).

---

## 1. Webhook sortant (le portail → n8n)

### Configuration

1. Dans n8n : créer un workflow commençant par un nœud **Webhook** (méthode POST) et copier son URL.
2. Dans le portail : **Paramètres ▸ Collaborateurs ▸ Intégration n8n** → coller l'URL, éventuellement définir un **secret partagé**, Enregistrer puis **« Envoyer un test »**.
3. Dans n8n, vérifier la réception du test, puis passer le webhook en production.

Si un secret est défini, chaque appel porte l'en-tête `X-Webhook-Secret` — à vérifier dans
n8n (nœud IF) pour refuser les appels étrangers.

### Événement `recuperation_terminee`

Envoyé à la fin de **chaque** récupération (lot planifié, « Tout récupérer », ou client
individuel) :

```json
{
  "evenement": "recuperation_terminee",
  "date": "2026-07-08T02:41:12.000Z",
  "cabinet": "Tarn Compta",
  "portail": "https://portail.tarncompta.fr",
  "source": "urssaf",
  "demarre_le": "2026-07-08T02:00:00.000Z",
  "fini_le": "2026-07-08T02:41:12.000Z",
  "clients_traites": 269,
  "succes": 265,
  "echecs": 4,
  "nouveaux_documents": 37,
  "nouveaux_documents_detail": [{ "id": 1748, "client": "MR BARTHE GHISLAIN", "libelle": "16/06/2026 — Régularisation de vos cotisations" }],
  "echecs_detail": [{ "nom": "SARL X", "message": "Aucun client trouve (…)" }]
}
```

`source` : `impots` | `urssaf` | `carpimko` | `carmf` | `carcdsf` | `carpv`.
`echecs_detail` est plafonné à 50 entrées, `nouveaux_documents_detail` à 200 (id
utilisable avec `GET /api/<source>/documents/:id/file` pour télécharger le PDF).
Pour la source `impots`, les messages de la messagerie portent en plus un champ
`"texte"` (contenu du message, plafonné à 3000 caractères) — pratique pour
l'afficher directement dans le corps d'un mail — et les avis CFE/taxe foncière
un champ `"paiement"` : `echeance` (prélèvement à l'échéance), `mensualise`,
`aucun` (pas de prélèvement — à payer) ou `inconnu`. L'événement `test` (bouton « Envoyer un
test ») porte la même enveloppe avec `"evenement": "test"`.

Le bilan porte aussi `comptes_verrouilles` : les clients dont le mot de passe a été
refusé (CARPIMKO, CARMF, CARCDSF, CARPV, URSSAF). **Ils sont exclus des tournées
automatiques** tant que personne ne ressaisit le mot de passe — d'où l'intérêt de les
faire remonter dans le mail de synthèse plutôt que de les laisser dans un journal
éphémère.

```json
"comptes_verrouilles": [{ "nom": "MME DUPONT", "message": "Connexion refusée : mot de passe invalide" }]
```

Idées de workflows : e-mail/Teams de synthèse après la tournée nocturne, alerte si
`echecs > 0`, création de tâches pour les clients en échec, archivage GED des nouveaux
documents (via l'API ci-dessous).

### Événement `tournee_manquee`

Envoyé quand une récupération **planifiée n'a pas eu lieu** : 2 h après l'heure prévue,
le portail vérifie en base qu'au moins une récupération de cet organisme a bien tourné.
Sinon (portail arrêté cette nuit-là, figé, ou lancement refusé), il alerte — une seule
fois par jour et par ligne de planification.

```json
{
  "evenement": "tournee_manquee",
  "source": "carpimko",
  "prevue_a": "02:00",
  "jour": "2026-07-26",
  "message": "La récupération CARPIMKO planifiée à 2 h n'a pas eu lieu (portail arrêté, figé, ou lancement refusé)."
}
```

Workflow n8n : envoyer un mail. C'est le signal qu'il faut aller voir le portail.

### Événement `portail_vivant` (battement de cœur)

Envoyé toutes les heures (`HEARTBEAT_MINUTES`, `0` pour désactiver), avec la version, la
durée de fonctionnement et les récupérations en cours.

```json
{ "evenement": "portail_vivant", "version": "1.11.0", "demarre_depuis_min": 143, "recuperations_en_cours": ["urssaf"] }
```

⚠️ **C'est l'ABSENCE de ce signal qui doit alerter** : un portail tombé ne peut pas
prévenir lui-même. Workflow n8n (« interrupteur d'homme mort ») : un nœud **Webhook**
qui, à chaque battement, réarme un délai ; si rien n'arrive pendant ~2 h, envoyer un
mail « le portail ne répond plus ». En pratique : stocker la date du dernier battement
(Data table, Redis, ou un simple fichier) et faire tourner un **Schedule** toutes les
30 min qui compare à l'heure courante.

Alternative sans battement : interroger `GET /api/sante` (**public**, aucune
authentification, aucune donnée sensible) depuis n8n ou un service de surveillance
(UptimeRobot…). Il renvoie `{"ok":true,"version":"…","uptime_min":…}` et **503** si la
base ne répond plus — ce qu'un simple « le port est ouvert » ne détecterait pas.

---

## 2. API entrante (n8n → le portail)

### Authentification

Générer la **clé API** dans Paramètres ▸ Collaborateurs ▸ « Clé API (MCP) » (elle n'est
visible qu'à la génération). Dans n8n, nœud **HTTP Request** avec un en-tête :

```
X-API-Key: <la clé>
```

Base : `https://portail.tarncompta.fr/api` (adapter au domaine du cabinet). La clé donne
un accès complet — la stocker dans un credential n8n, jamais en clair dans le workflow.

### Endpoints principaux

Sources : `impots` (préfixe `/api`), `urssaf` (`/api/urssaf`), caisses
(`/api/carpimko`, `/api/carmf`, `/api/carcdsf`, `/api/carpv`).

| Méthode | URL                                                                       | Rôle                                                             |
| ------- | ------------------------------------------------------------------------- | ---------------------------------------------------------------- |
| GET     | `/api/clients` · `/api/urssaf/clients` · `/api/<caisse>/clients`          | Liste des clients (nom, SIRET/identifiant, nb docs, dernier run) |
| GET     | `/api/documents` · `/api/urssaf/documents` · `/api/<caisse>/documents`    | Tous les documents de la source                                  |
| GET     | `/api/clients/:id/documents` (idem par source)                            | Documents d'un client                                            |
| GET     | `/api/urssaf/documents/:id/file` (idem par source)                        | Télécharger le PDF d'un document                                 |
| POST    | `/api/documents/zip` `{items:[{source,id}]}`                              | ZIP en masse (rangé par client)                                  |
| POST    | `/api/clients/:id/scrape` (impôts : `{cfe,tf,messagerie}`)                | Lancer la récupération d'un client                               |
| POST    | `/api/scrape-all` · `/api/urssaf/scrape-all` · `/api/<caisse>/scrape-all` | Tout récupérer (reprise automatique intégrée)                    |
| GET     | `/api/progress`                                                           | Avancement de la récupération en cours                           |
| GET     | `/api/runs` · `/api/urssaf/runs` · `/api/<caisse>/runs`                   | Historique des récupérations                                     |
| GET     | `/api/messages`                                                           | Messages de la messagerie impôts                                 |
| GET     | `/api/liste-noire` · `/api/urssaf/liste-noire`                            | Clients en liste noire                                           |

Notes : la récupération **impôts** exige la saisie manuelle d'une captcha dans le
portail — un `POST /api/scrape-all` impôts démarre la session mais attend un humain ;
les récupérations URSSAF/caisses sont entièrement automatiques. Les réponses des
`scrape-all` sont immédiates (`{started:true,…}`) : suivre via `/api/progress` ou
attendre le webhook `recuperation_terminee`.
