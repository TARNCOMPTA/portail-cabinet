// Serveur MCP expose en HTTP (transport « Streamable HTTP ») pour le connecteur
// distant de Claude. Memes outils que le MCP local (mcp-portail/) mais protege par
// OAuth (garde Bearer) et branche dans l'app Express du portail. Les outils appellent
// l'API HTTP locale du portail avec la cle API interne (donc toute la logique existante
// — validation, anti-doublon, verrous — est reutilisee).
import { McpServer } from '@modelcontextprotocol/sdk/server/mcp.js';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';
import { z } from 'zod';
import { getCleInterne } from './auth.js';
import { appelMyunisoft, appelMyunisoftBinaire } from './myunisoft.js';

const PORT = Number(process.env.PORT || 3003);
const LOCAL = `http://127.0.0.1:${PORT}`;

async function apiFetch(path, opts = {}) {
  const r = await fetch(`${LOCAL}${path}`, {
    ...opts,
    headers: { 'Content-Type': 'application/json', 'X-API-Key': getCleInterne(), ...(opts.headers || {}) },
  });
  const data = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(data.error || `Erreur ${r.status}`);
  return data;
}

const SOURCES = {
  impots: {
    clients: '/api/clients',
    add: '/api/clients',
    scrape: (id) => `/api/clients/${id}/scrape`,
    docs: (id) => `/api/clients/${id}/documents`,
    runs: '/api/runs',
    cle: 'siret',
  },
  urssaf: {
    clients: '/api/urssaf/clients',
    add: '/api/urssaf/clients',
    scrape: (id) => `/api/urssaf/clients/${id}/scrape`,
    docs: (id) => `/api/urssaf/clients/${id}/documents`,
    runs: '/api/urssaf/runs',
    cle: 'siret',
  },
  carpimko: {
    clients: '/api/carpimko/clients',
    add: '/api/carpimko/clients',
    scrape: (id) => `/api/carpimko/clients/${id}/scrape`,
    docs: (id) => `/api/carpimko/clients/${id}/documents`,
    runs: '/api/carpimko/runs',
    cle: 'login',
  },
  carmf: {
    clients: '/api/carmf/clients',
    add: '/api/carmf/clients',
    scrape: (id) => `/api/carmf/clients/${id}/scrape`,
    docs: (id) => `/api/carmf/clients/${id}/documents`,
    runs: '/api/carmf/runs',
    cle: 'login',
  },
  carcdsf: {
    clients: '/api/carcdsf/clients',
    add: '/api/carcdsf/clients',
    scrape: (id) => `/api/carcdsf/clients/${id}/scrape`,
    docs: (id) => `/api/carcdsf/clients/${id}/documents`,
    runs: '/api/carcdsf/runs',
    cle: 'login',
  },
  carpv: {
    clients: '/api/carpv/clients',
    add: '/api/carpv/clients',
    scrape: (id) => `/api/carpv/clients/${id}/scrape`,
    docs: (id) => `/api/carpv/clients/${id}/documents`,
    runs: '/api/carpv/runs',
    cle: 'login',
  },
  ir: {
    clients: '/api/ir/clients',
    add: '/api/ir/clients',
    scrape: (id) => `/api/ir/clients/${id}/scrape`,
    docs: (id) => `/api/ir/clients/${id}/documents`,
    runs: '/api/ir/runs',
    cle: 'login',
  },
};
const AVEC_MDP = new Set(['carpimko', 'carmf', 'carcdsf', 'carpv', 'ir']); // sources login+mot de passe par client
const nomFichier = (p) => (p || '').split(/[\\/]/).pop() || '';
const SRC = z.enum(['impots', 'urssaf', 'carpimko', 'carmf', 'carcdsf', 'carpv', 'ir']);
const txt = (o) => ({ content: [{ type: 'text', text: typeof o === 'string' ? o : JSON.stringify(o, null, 2) }] });
// MyUnisoft : lecture seule. Le jeton reste cote serveur (src/myunisoft.js), jamais expose a Claude.
async function myu(chemin, societeId) {
  const r = await appelMyunisoft(chemin, { timeoutMs: 30000, headers: societeId != null ? { 'society-id': String(societeId) } : {} });
  if (!r.ok) throw new Error(`MyUnisoft : ${r.error}`);
  return r.data;
}
async function myuFichier(chemin, societeId, opts = {}) {
  const r = await appelMyunisoftBinaire(chemin, { ...opts, headers: { 'society-id': String(societeId) } });
  if (!r.ok) throw new Error(`MyUnisoft : ${r.error}`);
  return r;
}
const MAX_PJ = 8 * 1024 * 1024; // au-dela, pas de fichier joint (resume seulement)
const DATE = z.string().regex(/^\d{4}-\d{2}-\d{2}$/, 'AAAA-MM-JJ');
const nombreFec = (v) =>
  Number(
    String(v || '0')
      .replace(/\s/g, '')
      .replace(',', '.'),
  ) || 0;
const erreur = (e) => ({ isError: true, content: [{ type: 'text', text: `Erreur : ${e.message}` }] });

function buildServer() {
  const server = new McpServer({ name: 'portail-cabinet', version: '1.0.0' });

  server.tool(
    'lister_clients',
    "Liste ou recherche les clients d'un organisme du Portail Cabinet (impots, urssaf, carpimko, carmf, carcdsf, carpv, ir = impôt sur le revenu / espace particulier), avec le statut et le message de leur dernière récupération.",
    { source: SRC, recherche: z.string().optional().describe('Filtre par nom / identifiant / notes') },
    async ({ source, recherche }) => {
      try {
        const cfg = SOURCES[source];
        let cs = await apiFetch(cfg.clients);
        if (recherche) {
          const q = recherche.toLowerCase();
          cs = cs.filter((c) => `${c.nom} ${c[cfg.cle] || ''} ${c.notes || ''}`.toLowerCase().includes(q));
        }
        return txt(
          cs.map((c) => ({
            id: c.id,
            nom: c.nom,
            [cfg.cle]: c[cfg.cle],
            documents: c.nb_docs ?? 0,
            verrouille: c.verrouille || false,
            dernier_run: c.dernier_run || null,
            dernier_statut: c.dernier_statut || null,
            dernier_message: c.dernier_message || null,
          })),
        );
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'ajouter_client',
    "Enregistre un nouveau client. carpimko/carmf/carcdsf/carpv : 'identifiant' = identifiant de connexion + 'mot_de_passe' OBLIGATOIRE ; ir : 'identifiant' = numéro fiscal (13 chiffres) + 'mot_de_passe' de l'espace particulier (carcdsf : préciser aussi 'profession' = cd ou sf). impots/urssaf : 'identifiant' = SIRET/SIREN (rattacher à un compte via 'cabinet_id' si connu).",
    {
      source: SRC,
      nom: z.string(),
      identifiant: z.string(),
      mot_de_passe: z.string().optional(),
      profession: z.enum(['cd', 'sf']).optional().describe('CARCDSF : cd = chirurgien-dentiste, sf = sage-femme'),
      notes: z.string().optional(),
      cabinet_id: z.number().optional(),
    },
    async ({ source, nom, identifiant, mot_de_passe, profession, notes, cabinet_id }) => {
      try {
        const body = { nom };
        if (AVEC_MDP.has(source)) {
          if (!mot_de_passe) throw new Error(`mot_de_passe requis pour ${source}.`);
          body.login = identifiant;
          body.password = mot_de_passe;
          if (notes) body.notes = notes;
          if (source === 'carcdsf') {
            if (!profession) throw new Error("profession requise pour carcdsf ('cd' ou 'sf').");
            body.profession = profession;
          }
        } else {
          body.siret = identifiant;
          if (cabinet_id) body.cabinet_id = cabinet_id;
        }
        const c = await apiFetch(SOURCES[source].add, { method: 'POST', body: JSON.stringify(body) });
        return txt({ ok: true, message: `Client « ${nom} » ajouté à ${source}.`, client: c });
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'recuperer_documents',
    "Lance la récupération des documents d'un client (par son id et son organisme). Le robot tourne sur le serveur ; pour les Impôts une captcha manuelle reste nécessaire (vue noVNC du portail).",
    { source: SRC, client_id: z.number() },
    async ({ source, client_id }) => {
      try {
        const r = await apiFetch(SOURCES[source].scrape(client_id), { method: 'POST', body: JSON.stringify({}) });
        return txt({ ok: true, message: 'Récupération lancée.', ...r });
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'lister_documents',
    "Liste les documents déjà récupérés d'un client (id, nom, date). L'id sert ensuite à telecharger_document.",
    { source: SRC, client_id: z.number() },
    async ({ source, client_id }) => {
      try {
        const ds = await apiFetch(SOURCES[source].docs(client_id));
        return txt(
          ds.map((d) => ({
            id: d.id,
            nom: d.libelle || nomFichier(d.fichier) || `document ${d.id}`,
            fichier: nomFichier(d.fichier),
            date: d.recupere_le || d.date || null,
          })),
        );
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'telecharger_document',
    'Télécharge un document par son id et son organisme. Renvoie le FICHIER lui-même (joint dans la conversation sur les clients qui le supportent) + un lien de secours (usage unique, 10 min).',
    { source: SRC, document_id: z.number() },
    async ({ source, document_id }) => {
      try {
        // 1er lien -> on lit les octets en local pour joindre le fichier
        const r1 = await apiFetch('/api/documents/lien', { method: 'POST', body: JSON.stringify({ source, document_id }) });
        const filename = r1.filename;
        const tok = String(r1.url).split('/dl/')[1];
        const fr = await fetch(`${LOCAL}/dl/${tok}`);
        if (!fr.ok) throw new Error(`Téléchargement impossible (${fr.status}).`);
        const mime = fr.headers.get('content-type') || 'application/octet-stream';
        const buf = Buffer.from(await fr.arrayBuffer());
        // 2e lien (frais) renvoye comme secours / pour usage hors chat
        const r2 = await apiFetch('/api/documents/lien', { method: 'POST', body: JSON.stringify({ source, document_id }) });
        const MAX = 8 * 1024 * 1024;
        const content = [
          {
            type: 'text',
            text: JSON.stringify({
              ok: true,
              filename,
              taille: buf.length,
              url: r2.url,
              note: 'Fichier joint ci-dessus si le client le supporte ; sinon lien valable 10 min (usage unique).',
            }),
          },
        ];
        if (buf.length <= MAX) {
          content.unshift({
            type: 'resource',
            resource: { uri: `portail://${source}/document/${document_id}/${encodeURIComponent(filename)}`, mimeType: mime, blob: buf.toString('base64') },
          });
        }
        return { content };
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'historique_recuperations',
    "Historique des récupérations d'un organisme (date, client, statut succes/echec/echec_mdp, message d'erreur, nb de documents), du plus récent au plus ancien. Filtrable par client_id. Sert à diagnostiquer un échec.",
    {
      source: SRC,
      client_id: z.number().optional().describe('Limiter à un client'),
      limite: z.number().int().min(1).max(200).optional().describe('Nombre de lignes (défaut 20)'),
    },
    async ({ source, client_id, limite }) => {
      try {
        let runs = await apiFetch(SOURCES[source].runs);
        if (client_id != null) runs = runs.filter((r) => r.client_id === client_id);
        return txt(
          runs.slice(0, limite ?? 20).map((r) => ({
            date: r.lance_le,
            client_id: r.client_id,
            client: r.client_nom || null,
            statut: r.statut,
            message: r.message || null,
            nb_docs: r.nb_docs ?? 0,
          })),
        );
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'saisir_code',
    "Saisit le code attendu par le bandeau du portail : code de double authentification CARCDSF reçu par e-mail (6 caractères). Vérifier d'abord avec etat_recuperation (saisie_attendue).",
    { code: z.string().min(4).max(12) },
    async ({ code }) => {
      try {
        const r = await apiFetch('/api/captcha', { method: 'POST', body: JSON.stringify({ code }) });
        return txt(r.connecte ? { ok: true, message: 'Code accepté — la connexion et la récupération continuent.' } : { ok: false, ...r, image: undefined });
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'diagnostic_ir',
    "Dernier passage du connecteur impôt sur le revenu (espace particulier) pour un client : pages vues (titres, liens, boutons), fichiers tentés et leur résultat, erreur éventuelle. Sert à cartographier l'espace particulier et à diagnostiquer un échec.",
    { client_id: z.number() },
    async ({ client_id }) => {
      try {
        return txt(await apiFetch(`/api/ir-diagnostic/${client_id}`));
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool('etat_recuperation', 'État de la récupération en cours sur le portail (progression + dernières lignes du journal).', {}, async () => {
    try {
      const p = await apiFetch('/api/progress');
      const saisie = await apiFetch('/api/captcha').catch(() => ({}));
      // Plusieurs organismes peuvent tourner en parallele : on remonte le total agrege
      // ET le detail par source (fait/total/client en cours).
      const detail = Object.values(p.sources || {}).map((s) => ({
        source: s.source,
        actif: !!s.actif,
        fait: s.fait,
        total: s.total,
        en_cours: s.courant || null,
      }));
      return txt({
        actif: p.actif,
        fait: p.fait,
        total: p.total,
        en_cours: p.courant,
        sources_actives: p.actives || [],
        par_source: detail,
        derniers_logs: (p.logs || []).slice(-8),
        // Bandeau en attente : code de double authentification CARCDSF (texte) ou captcha impots (image).
        saisie_attendue: saisie.actif ? { type: saisie.image ? 'captcha_impots' : 'code', titre: saisie.titre, message: saisie.message } : null,
      });
    } catch (e) {
      return erreur(e);
    }
  });

  server.tool(
    'myunisoft_lister_dossiers',
    "Liste les dossiers (sociétés) du cabinet dans MyUnisoft : id (society_id), nom, SIRET, ville. Filtrable par nom/SIRET/ville. L'id sert aux autres outils myunisoft_*. Lecture seule.",
    { recherche: z.string().optional().describe('Filtre par nom, SIRET ou ville') },
    async ({ recherche }) => {
      try {
        const d = await myu('/society?mode=1&limit=1000');
        let l = (d?.society_array || []).map((s) => ({ id: s.society_id, nom: s.name, siret: s.siret || null, ville: s.city || null }));
        if (recherche) {
          const q = recherche.toLowerCase();
          l = l.filter((s) => `${s.nom} ${s.siret || ''} ${s.ville || ''}`.toLowerCase().includes(q));
        }
        return txt({ total: l.length, dossiers: l.sort((a, b) => a.nom.localeCompare(b.nom, 'fr')) });
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'myunisoft_exercices',
    "Exercices comptables d'un dossier MyUnisoft (id, dates, clos ou non, CA, résultat). Lecture seule.",
    { dossier_id: z.number().describe('society_id (voir myunisoft_lister_dossiers)') },
    async ({ dossier_id }) => {
      try {
        const d = await myu('/society/exercice', dossier_id);
        const l = Array.isArray(d) ? d : d?.array || [];
        return txt(
          l.map((e) => ({
            exercice_id: e.exercice_id,
            debut: e.start_date,
            fin: e.end_date,
            libelle: e.label,
            clos: e.closed,
            ca: e.ca,
            resultat: e.result,
            logiciel: e.used_software,
          })),
        );
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'myunisoft_dossier_fiscal',
    "Dossier fiscal d'un dossier MyUnisoft (régimes, OG, signataire, déclarations par le cabinet…), tel que renvoyé par l'API. Lecture seule.",
    { dossier_id: z.number().describe('society_id (voir myunisoft_lister_dossiers)') },
    async ({ dossier_id }) => {
      try {
        return txt(await myu('/society/fiscal_file', dossier_id));
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'myunisoft_documents_en_attente',
    'Documents déposés en attente de traitement sur un dossier MyUnisoft. Lecture seule.',
    {
      dossier_id: z.number().describe('society_id (voir myunisoft_lister_dossiers)'),
      limite: z.number().int().min(1).max(200).optional().describe('Nombre max (défaut 50)'),
    },
    async ({ dossier_id, limite }) => {
      try {
        return txt(await myu(`/document/pending?limit=${limite ?? 50}`, dossier_id));
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'myunisoft_balance',
    "Balance d'un dossier MyUnisoft pour un exercice : solde par compte (débit − crédit : positif = débiteur, négatif = créditeur), hors journaux OD extracomptables, avec contrôle d'équilibre. Lecture seule.",
    {
      dossier_id: z.number().describe('society_id (voir myunisoft_lister_dossiers)'),
      exercice_id: z.number().describe('exercice_id (voir myunisoft_exercices)'),
      classes: z
        .array(z.string().regex(/^\d{1,8}$/))
        .optional()
        .describe("Racines de comptes à inclure, ex. ['6','7'] ou ['401','411']. Défaut : classes 1 à 7"),
    },
    async ({ dossier_id, exercice_id, classes }) => {
      try {
        const racines = classes?.length ? classes : ['1', '2', '3', '4', '5', '6', '7'];
        const qs = [`version=1.0.0`, `idExercice=${exercice_id}`, ...racines.map((c) => `classAccount=${encodeURIComponent(c + '%')}`)].join('&');
        const d = await myu(`/mad/balance?${qs}`, dossier_id);
        const lignes = (Array.isArray(d) ? d : []).map((l) => ({ compte: l.account?.number, libelle: l.account?.name, solde: l.balance }));
        const arrondi = (n) => Math.round(n * 100) / 100;
        const debit = arrondi(lignes.filter((l) => l.solde > 0).reduce((t, l) => t + l.solde, 0));
        const credit = arrondi(lignes.filter((l) => l.solde < 0).reduce((t, l) => t - l.solde, 0));
        return txt({ nb_comptes: lignes.length, total_debiteur: debit, total_crediteur: credit, ecart: arrondi(debit - credit), comptes: lignes });
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'myunisoft_grand_livre',
    "Grand livre d'un dossier MyUnisoft sur une période (max 12 mois), renvoyé en PDF joint. Options : lettrage, non soldés. Lecture seule.",
    {
      dossier_id: z.number().describe('society_id (voir myunisoft_lister_dossiers)'),
      debut: DATE.describe('Date de début'),
      fin: DATE.describe('Date de fin'),
      non_lettres_seulement: z.boolean().optional().describe('Uniquement les écritures non lettrées'),
      non_soldes_seulement: z.boolean().optional().describe('Uniquement les comptes non soldés'),
    },
    async ({ dossier_id, debut, fin, non_lettres_seulement, non_soldes_seulement }) => {
      try {
        const qs = new URLSearchParams({
          start_date: debut,
          end_date: fin,
          not_lettered_only: String(!!non_lettres_seulement),
          not_solde_only: String(!!non_soldes_seulement),
        });
        const r = await myuFichier(`/grand_livre?${qs}`, dossier_id, { timeoutMs: 120000 });
        const filename = `grand-livre-${dossier_id}-${debut}_${fin}.pdf`;
        const content = [
          {
            type: 'text',
            text: JSON.stringify({
              ok: true,
              filename,
              type: r.type,
              taille: r.buf.length,
              ...(r.buf.length > MAX_PJ ? { note: 'Trop volumineux pour être joint : réduire la période.' } : {}),
            }),
          },
        ];
        if (r.buf.length <= MAX_PJ)
          content.unshift({
            type: 'resource',
            resource: { uri: `myunisoft://dossier/${dossier_id}/${filename}`, mimeType: r.type.split(';')[0], blob: r.buf.toString('base64') },
          });
        return { content };
      } catch (e) {
        return erreur(e);
      }
    },
  );

  server.tool(
    'myunisoft_fec',
    "Export FEC d'un dossier MyUnisoft, soit pour un exercice (exercice_id), soit pour une période (debut + fin). Renvoie un résumé (nombre de lignes, totaux débit/crédit, équilibre, aperçu) et le fichier FEC joint. Lecture seule.",
    {
      dossier_id: z.number().describe('society_id (voir myunisoft_lister_dossiers)'),
      exercice_id: z.number().optional().describe('exercice_id (voir myunisoft_exercices) — ou bien debut + fin'),
      debut: DATE.optional(),
      fin: DATE.optional(),
    },
    async ({ dossier_id, exercice_id, debut, fin }) => {
      try {
        const qs = new URLSearchParams();
        if (exercice_id != null) {
          qs.set('export_type', '0');
          qs.set('exercice_id', String(exercice_id));
        } else if (debut && fin) {
          qs.set('export_type', '1');
          qs.set('from', debut);
          qs.set('to', fin);
        } else throw new Error('Préciser exercice_id, ou debut + fin.');
        const r = await myuFichier(`/export/fec?${qs}`, dossier_id, { method: 'POST', body: {}, timeoutMs: 180000 });
        const texte = r.buf.toString('utf8').replace(/^\uFEFF/, '');
        const lignes = texte.split(/\r?\n/).filter(Boolean);
        const iD = lignes[0]?.split('|').indexOf('Debit') ?? -1;
        const iC = lignes[0]?.split('|').indexOf('Credit') ?? -1;
        let debit = 0;
        let credit = 0;
        if (iD >= 0 && iC >= 0)
          for (const l of lignes.slice(1)) {
            const c = l.split('|');
            debit += nombreFec(c[iD]);
            credit += nombreFec(c[iC]);
          }
        const arrondi = (n) => Math.round(n * 100) / 100;
        const filename = `FEC-${dossier_id}-${exercice_id != null ? `ex${exercice_id}` : `${debut}_${fin}`}.txt`;
        const resume = {
          ok: true,
          filename,
          taille: r.buf.length,
          nb_ecritures_lignes: Math.max(lignes.length - 1, 0),
          total_debit: arrondi(debit),
          total_credit: arrondi(credit),
          ecart: arrondi(debit - credit),
          apercu: lignes.slice(0, 6),
        };
        const content = [{ type: 'text', text: JSON.stringify(resume, null, 2) }];
        if (r.buf.length <= MAX_PJ)
          content.unshift({ type: 'resource', resource: { uri: `myunisoft://dossier/${dossier_id}/${filename}`, mimeType: 'text/plain', text: texte } });
        return { content };
      } catch (e) {
        return erreur(e);
      }
    },
  );

  return server;
}

export function installMcp(app, guard) {
  app.post('/mcp', guard, async (req, res) => {
    try {
      const server = buildServer();
      const transport = new StreamableHTTPServerTransport({ sessionIdGenerator: undefined }); // sans session (stateless)
      res.on('close', () => {
        transport.close();
        server.close();
      });
      await server.connect(transport);
      await transport.handleRequest(req, res, req.body);
    } catch (e) {
      if (!res.headersSent) res.status(500).json({ jsonrpc: '2.0', error: { code: -32603, message: String(e.message) }, id: null });
    }
  });
  // Mode sans session : pas de flux SSE persistant ni de suppression de session.
  app.get('/mcp', guard, (req, res) => res.status(405).json({ jsonrpc: '2.0', error: { code: -32000, message: 'Method Not Allowed.' }, id: null }));
  app.delete('/mcp', guard, (req, res) => res.status(405).end());
}
